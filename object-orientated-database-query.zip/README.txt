A Pen created at CodePen.io. You can find this one at https://codepen.io/AceXintense/pen/RWByxp.

 This is a Simple Object Orientated Database which the User can Add and Query the Database.