A Pen created at CodePen.io. You can find this one at https://codepen.io/cyandream/pen/dYeoGq.

 Using the Open Movie Database to search for movie titles